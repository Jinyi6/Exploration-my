---
task_categories:
- text-generation
language:
- en
pretty_name: MATH-500
---

# Dataset Card for MATH-500

<!-- Provide a quick summary of the dataset. -->

This dataset contains a subset of 500 problems from the MATH benchmark that OpenAI created in their _Let's Verify Step by Step_ paper. See their GitHub repo for the source file: https://github.com/openai/prm800k/tree/main?tab=readme-ov-file#math-splits